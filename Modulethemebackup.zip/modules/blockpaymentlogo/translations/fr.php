<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Bloc des logos de paiement';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Ajoute un bloc qui affiche tous vos logos de paiement.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Aucune page CMS n\'est disponible';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Page de destination pour le lien du bloc';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';


return $_MODULE;
