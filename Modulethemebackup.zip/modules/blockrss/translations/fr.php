<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockrss}prestashop>blockrss_2516c13a12d3dbaf4efa88d9fce2e7da'] = 'Bloc flux RSS';
$_MODULE['<{blockrss}prestashop>blockrss_4bb9f05422c5afbb84ed1eeb39beb8c6'] = 'Ajoute un bloc affichant un flux RSS.';
$_MODULE['<{blockrss}prestashop>blockrss_9680162225162baf2a085dfdc2814deb'] = 'Flux RSS';
$_MODULE['<{blockrss}prestashop>blockrss_6706b6d8ba45cc4f0eda0506ba1dc3c8'] = 'URL non valable pour le flux';
$_MODULE['<{blockrss}prestashop>blockrss_36ed65ce17306e812fd68d9f634c0c57'] = 'Titre non valable';
$_MODULE['<{blockrss}prestashop>blockrss_1b3d34e25aef32a3c8daddfff856577f'] = 'Nombre de flux non valable';
$_MODULE['<{blockrss}prestashop>blockrss_549a15a569b4e5e250275db17712cd91'] = 'Vous avez sélectionné le flux RSS de votre propre boutique. Veuillez en choisir un autre.';
$_MODULE['<{blockrss}prestashop>blockrss_bef637cd0e222a8b56676cb64ce75258'] = 'Le flux est inaccessible, vérifiez votre URL';
$_MODULE['<{blockrss}prestashop>blockrss_1844ef1bfaa030dc8423c4645a43525c'] = 'Flux non valable :';
$_MODULE['<{blockrss}prestashop>blockrss_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour réussie';
$_MODULE['<{blockrss}prestashop>blockrss_0a1c629f0e86804a9e165f4b1ee399b7'] = 'Erreur: Flux RSS invalide dans le module \\"blockrss\\" : %s';
$_MODULE['<{blockrss}prestashop>blockrss_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockrss}prestashop>blockrss_b22c8f9ad7db023c548c3b8e846cb169'] = 'Titre du bloc';
$_MODULE['<{blockrss}prestashop>blockrss_5a33009bfebd22448e4265f65f8a7d98'] = 'Créer un titre pour le bloc (par défaut : "RSS feed").';
$_MODULE['<{blockrss}prestashop>blockrss_402d00ca8e4f0fff26fc24ee9ab8e82b'] = 'Ajouter une URL';
$_MODULE['<{blockrss}prestashop>blockrss_3117d1276345461366a62c6950c186ed'] = 'Ajoutez l\'URL du flux que vous voulez utiliser (exemple : http://news.google.com/?output=rss).';
$_MODULE['<{blockrss}prestashop>blockrss_ff9aa540e20285875ac8b190a3cb7ccf'] = 'Nombre de messages affichés';
$_MODULE['<{blockrss}prestashop>blockrss_0b4c4685f03f258492af3705a03b619b'] = 'Nombre de fils affichés dans le bloc (par défaut : 5).';
$_MODULE['<{blockrss}prestashop>blockrss_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockrss}prestashop>blockrss_10fd25dcd3353c0ba3731d4a23657f2e'] = 'Aucun flux RSS ajouté';


return $_MODULE;
